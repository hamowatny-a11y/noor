<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Noor ❤️</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="background"></div>

<main class="card">

    <img src="images/noor.jpg" alt="Noor" class="avatar">

    <span class="status">❤️ TAKEN</span>

    <h1>Noor.</h1>

    <p>
        There are billions of people.
        <br>
        I chose one.
    </p>

    <div class="line"></div>

    <div class="counter">

        <div>
            <h2 id="days">13</h2>
            <span>Days Together</span>
        </div>

    </div>

    <button id="loveBtn">
        ❤️
    </button>

    <div id="message" class="hidden">
        No replacements.<br>
        No second choice.<br><br>

        Just Noor.
    </div>

</main>

<div id="hearts"></div>

<audio id="music" loop>
    <source src="music.mp3" type="audio/mpeg">
</audio>

<script src="script.js"></script>

</body>
</html>